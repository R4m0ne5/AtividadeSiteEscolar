<?php
    require_once 'conexao.php';

    class usuarioDAO {

        public function buscarUsuario(usuarioModel $usuario) {
            $conexao = (new conexao())->getConexao();

            $sql = "SELECT * FROM usuario WHERE email = :email AND senha = :senha;";
    
            $stmt = $conexao->prepare($sql);
            $stmt->bindValue(':email', $usuario->email);
            $stmt->bindValue(':senha', $usuario->senha);
            $stmt->execute();
            
            return $stmt->fetch(PDO::FETCH_ASSOC);
        }

        public function buscarUsuarios() {
            $conexao = (new conexao())->getConexao();

            $sql = "SELECT * FROM usuario;";

            $stmt = $conexao->prepare($sql);
            $stmt->execute();
            
            return $stmt->fetchAll(PDO::FETCH_ASSOC);
        }

        public function inserirUsuario(usuarioModel $usuario) {
            $conexao = (new conexao())->getConexao();

            $sql = "INSERT INTO usuario VALUES(null, :idTipoUsuario, :nome, :email, :senha);";

            $stmt = $conexao->prepare($sql);
            $stmt->bindValue(':idTipoUsuario', $usuario->idTipoUsuario);
            $stmt->bindValue(':nome', $usuario->nome);
            $stmt->bindValue(':email', $usuario->email);
            $stmt->bindValue(':senha', $usuario->senha);
            
            $retorno = $stmt->execute();

            return $retorno;
        }

        public function atualizarUsuario(usuarioModel $usuario) {
            $conexao = (new conexao())->getConexao();

            $sql = "UPDATE usuario SET nome = :nome and email = :email WHERE id_usuario = :id_usuario;";
        
            $stmt = $conexao->prepare($sql);
            $stmt->bindValue(':nome', $usuario->nome);
            $stmt->bindValue(':email', $usuario->email);
            $stmt->bindValue('id_usuario', $usuario->idUsuario);

            return $stmt->execute();
        }

        public function excluirUsuario(int $idUsuario) {
            $conexao = (new conexao())->getConexao();

            $sql = "DELETE FROM usuario WHERE id_usuario = :idUsuario";

            $stmt = $conexao->prepare($sql);
            $stmt->bindValue(':idUsuario', $idUsuario);
            return $stmt->execute();
        }
    }
    
?>
