<?php
    require_once 'DAL/tipoUsuarioDAO.php';

    class tipoUsuarioModel {
        public ?int $idTipoUsuario;
        public ?string $descricao;

        public function __construct(?int $idTipoUsuario = null, ?string $descricao = null) {
            $this->idTipoUsuario = $idTipoUsuario;
            $this->descricao = $descricao;
        }

        public function buscarTiposUsuario(){
            $tipoUsuarioDAO = new tipoUsuarioDAO();
            $tiposUsuario = $tipoUsuarioDAO->buscarTiposUsuario();

            foreach($tiposUsuario as $chave => $tipoUsuario){
                $tiposUsuario[$chave] = new self($tipoUsuario['id_tipo_usuario'], $tipoUsuario['descricao']);
            }

            return $tiposUsuario;
        }

        public function buscarTipoUsuarioPorId(int $idTipoUsuario) {
            $tipoUsuarioDAO = new tipoUsuarioDAO();
            $tipoUsuario = $tipoUsuarioDAO->buscarTipoUsuarioPorId($idTipoUsuario);
            return new usuarioModel($tipoUsuario['id_tipo_usuario'], $tipoUsuario['descricao']);
        }
    }
?>