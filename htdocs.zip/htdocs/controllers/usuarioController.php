<?php
    require_once '../models/usuarioModel.php';

    class usuarioController {
         public function validarUsuario(string $email, string $senha) {
            $email = str_replace(' ', '', $email);
            $senha = md5(str_replace(' ', '', $senha));

            $usuarioModel = new usuarioModel();
            $usuario = new usuarioModel(null, null, null, $email, $senha);

            $retorno = $usuarioModel->buscarUsuario($usuario);

            session_start();

            if ($retorno) {
                $_SESSION['esta_logado'] = True;
                $_SESSION['id_tipo_usuario'] = $retorno['id_tipo_usuario'];
                $_SESSION['id_usuario'] = $retorno['id_usuario'];
                header('Location: ../views/principal.php');
                
            }
            else {
                header('Location: ../views/login.php');
            }

            exit();
        }

        public function cadastrarUsuario(string $nome, string $email, string $senha, int $idTipoUsuario) {
            $email = str_replace(' ', '', $email);
            $senha = md5(str_replace(' ', '', $senha));

            $usuarioModel = new usuarioModel();
            $usuario = new usuarioModel(null, $idTipoUsuario, $nome, $email, $senha);
            $retorno = $usuarioModel->inserirUsuario($usuario);
            
            if ($retorno === true) {
                header('Location: ../views/listarUsuarios.php');
            }
            else {
                header('Location: ../views/login.php');
            }

            exit();
        }

        public function atualizarUsuario(string $nome, string $email) {
            $usuarioModel = new usuarioModel();

            $usuario = new usuarioModel(null, null, $nome, $email, null);

            $retorno = $usuarioModel->atualizarUsuario($usuario);

            if ($retorno) {
                header('Location: ../views/principal.php');
            }
            else {
                header("Location: ../views/editarAluno.php");
            }

            exit();
        }

        public function excluirUsuario(int $idUsuario) {
            $usuarioModel = new usuarioModel();

            $usuarioModel->excluirUsuario($idUsuario);

            header('Location: ../views/listarUsuarios.php');
            exit();
        }
    }
?>