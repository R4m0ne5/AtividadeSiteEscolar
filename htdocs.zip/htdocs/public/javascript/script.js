function validarCamposCadastrarUsuario(event) {
    const nome = document.getElementById('nome').value;
    const email = document.getElementById('email').value;
    const senha = document.getElementById('senha').value;
    const option = document.getElementById('id_tipo_usuario').value;

    if (nome == "" || email == "" || senha == "" || option == 0 || option == "0" || option === ""){
        alert('Preencha todos os campos corretamente!');

        event.preventDefault();

        return false;
    }
    

    return true;
}

function confirmarExcluir() {
    var confirmar = confirm("Você gostaria de excluir este campo?");

    return confirmar;
}