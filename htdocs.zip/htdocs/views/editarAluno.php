<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Editar usuario</title>
    <link rel="stylesheet" href="../public/css/style.css">
</head>
<?php
    require_once '../models/usuarioModel.php';

    session_start();

    if ($_SESSION['esta_logado'] !== true){
        header('Location: login.php');
        exit();
    }

    $usuarioModel = new usuarioModel();
?>
<body>
    <header>
        <?php require_once '../public/html/menuAluno.html'; ?>
        <h1>Alterar Credenciais</h1>
    </header>
    <main>
        <form action="../routers/usuarioRouter.php" method="post" onsubmit="return validarCamposCadastrarUsuario(event);">
            <label for="nome">Usuário</label>
            <br>
            <input type="text" name="nome" id="nome">
            <br>
            <label for="email">E-mail</label>
            <br>
            <input type="email" name="email" id="email">
            <br>
            <br>
            <input type="hidden" name="idUsuario" id="idUsuario" value="<?$_SESSION['id_usuario']?>">
            <input type="hidden" name="rota" id="rota" value="salvar">
            <input type="submit" value="Salvar">
        </form>
    </main>
</body>
</html>