<?php
    require_once '../controllers/usuarioController.php';

    $usuarioController = new usuarioController();

    $rota = $_POST['rota'];

    switch($rota) {
        case "entrar":
            $email = $_POST['email'];
            $senha = $_POST['senha'];


            $usuarioController->validarUsuario($email, $senha);

            break;

        case "cadastrar":
            $nome = $_POST['nome'];
            $email = $_POST['email'];
            $senha = $_POST['senha'];
            $idTipoUsuario = $_POST['id_tipo_usuario'];

            $usuarioController->cadastrarUsuario($nome, $email, $senha, $idTipoUsuario);

            break;

        case "salvar":
            $nome = $_POST['nome'];
            $email = $_POST['email'];
            $idUsuario = $_POST['idUsuario'];

            $usuarioController->atualizarUsuario($nome, $email, $idUsuario);

            break;

        case "excluir":
            $idUsuario = $_POST['idUsuario'];
    
            $usuarioController->excluirUsuario($idUsuario);
    
            break;
    
    }

?>

